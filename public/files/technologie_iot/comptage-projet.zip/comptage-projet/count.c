#include "contiki.h"
#include "dev/leds.h"
#include <stdio.h>

PROCESS(count_process, "Count process");
AUTOSTART_PROCESSES(&count_process);

PROCESS_THREAD(count_process, ev, data)
{
  PROCESS_BEGIN();
  printf("Counting.\n");
  PROCESS_END();
}
